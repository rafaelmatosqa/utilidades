# API Automation Template

Template Java 21 para automação de testes de API com RestAssured, TestNG, Lombok, Gradle, Extent Report, Kafka e Oracle.

## Arquitetura

```text
src/main/java/com/company/automation
├── base          # Setup comum de suites/testes
├── client        # Clients RestAssured por API/recurso
├── dto           # DTOs de request/response com Lombok
├── factory       # DataFactory pattern para massa dinâmica
├── spec          # Request/Response specs RestAssured
├── validation    # Validações reutilizáveis: status, schema, conteúdo
├── properties    # Leitura de env properties e variáveis de ambiente
├── database      # Execução e log de queries
├── kafka         # Consumo/publicação de mensagens Kafka
├── report        # Extent Report e logs técnicos
└── listener      # Listener TestNG

src/test/java/com/company/automation/tests
├── healthcheck
├── smoke
├── regression
└── e2e
```

## Execução local

```bash
gradle clean test -Dsuite=healthcheck -Denv=dev
gradle clean test -Dsuite=smoke -Denv=dev
gradle clean test -Dsuite=regression -Denv=hml
gradle clean test -Dsuite=e2e -Denv=hml
```

## Estratégia de testes

- **Healthcheck:** valida disponibilidade mínima da API e dependências críticas.
- **Smoke:** valida endpoints/fluxos essenciais após deploy.
- **Regression:** valida contratos, schemas, regras de negócio, erros e compatibilidade.
- **E2E:** valida jornada completa com múltiplas APIs, banco e Kafka.

## Logs no Extent Report

Use `ReportLogger.request`, `ReportLogger.response`, `ReportLogger.query` e `ReportLogger.kafka` nos pontos relevantes do teste ou client para anexar evidências ao relatório.

## CI/CD GitLab

Pipeline em `.gitlab-ci.yml` com stages sequenciais: healthcheck, smoke, regression e e2e. Configure variáveis protegidas como `DB_PASSWORD`, credenciais e endpoints sensíveis no GitLab CI/CD Variables.

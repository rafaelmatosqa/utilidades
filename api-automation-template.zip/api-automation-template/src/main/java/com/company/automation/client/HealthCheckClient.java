package com.company.automation.client;

import com.company.automation.properties.EnvProperties;
import com.company.automation.spec.RequestSpecFactory;
import io.restassured.response.ValidatableResponse;

import static io.restassured.RestAssured.given;

public class HealthCheckClient {
    public ValidatableResponse getHealth() {
        return given()
                .spec(RequestSpecFactory.defaultSpec())
                .when()
                .get(EnvProperties.get("healthcheck.path"))
                .then();
    }
}

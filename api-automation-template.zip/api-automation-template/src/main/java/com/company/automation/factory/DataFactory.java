package com.company.automation.factory;

import com.github.javafaker.Faker;
import java.util.Locale;

public final class DataFactory {
    private static final Faker FAKER = new Faker(new Locale("pt-BR"));
    private DataFactory() {}

    public static String correlationId() {
        return FAKER.internet().uuid();
    }

    public static String randomDocument() {
        return FAKER.number().digits(11);
    }
}

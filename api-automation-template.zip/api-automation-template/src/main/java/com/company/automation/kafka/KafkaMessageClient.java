package com.company.automation.kafka;

import com.company.automation.properties.EnvProperties;
import com.company.automation.report.ReportLogger;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.serialization.StringDeserializer;

import java.time.Duration;
import java.util.*;

public class KafkaMessageClient {
    public List<String> consumeMessages(String topic, Duration timeout) {
        Properties props = new Properties();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, EnvProperties.get("kafka.bootstrap.servers"));
        props.put(ConsumerConfig.GROUP_ID_CONFIG, EnvProperties.get("kafka.group.id"));
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");

        try (KafkaConsumer<String, String> consumer = new KafkaConsumer<>(props)) {
            consumer.subscribe(List.of(topic));
            ConsumerRecords<String, String> records = consumer.poll(timeout);
            List<String> messages = new ArrayList<>();
            records.forEach(record -> {
                messages.add(record.value());
                ReportLogger.kafka(record.value());
            });
            return messages;
        }
    }
}

package com.company.automation.report;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public final class ExtentManager {
    private static ExtentReports extent;
    private ExtentManager() {}

    public static synchronized void initReport() {
        if (extent == null) {
            ExtentSparkReporter reporter = new ExtentSparkReporter("build/reports/extent/extent-report.html");
            reporter.config().setDocumentTitle("API Automation Report");
            reporter.config().setReportName("RestAssured TestNG API Tests");
            extent = new ExtentReports();
            extent.attachReporter(reporter);
        }
    }

    public static ExtentReports getExtent() { return extent; }
    public static void flushReport() { if (extent != null) extent.flush(); }
}

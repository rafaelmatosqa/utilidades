package com.company.automation.validation;

import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.ValidatableResponse;

import static org.hamcrest.Matchers.notNullValue;

public final class CommonValidations {
    private CommonValidations() {}

    public static void statusCode(ValidatableResponse response, int statusCode) {
        response.statusCode(statusCode);
    }

    public static void schema(ValidatableResponse response, String schemaPath) {
        response.body(JsonSchemaValidator.matchesJsonSchemaInClasspath(schemaPath));
    }

    public static void fieldNotNull(ValidatableResponse response, String jsonPath) {
        response.body(jsonPath, notNullValue());
    }
}

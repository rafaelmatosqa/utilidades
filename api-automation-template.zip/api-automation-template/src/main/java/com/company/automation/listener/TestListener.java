package com.company.automation.listener;

import com.company.automation.report.ReportLogger;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class TestListener implements ITestListener {
    @Override public void onTestStart(ITestResult result) { ReportLogger.startTest(result.getMethod().getMethodName()); }
    @Override public void onTestSuccess(ITestResult result) { ReportLogger.pass("Teste executado com sucesso"); }
    @Override public void onTestFailure(ITestResult result) { ReportLogger.fail(result.getThrowable()); }
}

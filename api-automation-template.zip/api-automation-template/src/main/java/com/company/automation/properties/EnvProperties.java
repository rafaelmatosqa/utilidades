package com.company.automation.properties;

import java.io.InputStream;
import java.util.Optional;
import java.util.Properties;

public final class EnvProperties {
    private static final Properties PROPERTIES = new Properties();

    static {
        String env = System.getProperty("env", "dev");
        String fileName = "env-" + env + ".properties";
        try (InputStream input = EnvProperties.class.getClassLoader().getResourceAsStream(fileName)) {
            if (input == null) throw new IllegalStateException("Arquivo não encontrado: " + fileName);
            PROPERTIES.load(input);
        } catch (Exception e) {
            throw new RuntimeException("Erro ao carregar properties do ambiente", e);
        }
    }

    private EnvProperties() {}

    public static String get(String key) {
        return Optional.ofNullable(System.getenv(key.toUpperCase().replace('.', '_')))
                .orElseGet(() -> PROPERTIES.getProperty(key));
    }
}

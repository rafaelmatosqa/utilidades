package com.company.automation.database;

import com.company.automation.properties.EnvProperties;
import com.company.automation.report.ReportLogger;

import java.sql.*;
import java.util.*;

public class OracleDatabaseClient {
    public List<Map<String, Object>> query(String sql) {
        ReportLogger.query(sql);
        try (Connection conn = DriverManager.getConnection(EnvProperties.get("db.url"), EnvProperties.get("db.user"), EnvProperties.get("db.password"));
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            List<Map<String, Object>> rows = new ArrayList<>();
            ResultSetMetaData meta = rs.getMetaData();
            while (rs.next()) {
                Map<String, Object> row = new LinkedHashMap<>();
                for (int i = 1; i <= meta.getColumnCount(); i++) row.put(meta.getColumnName(i), rs.getObject(i));
                rows.add(row);
            }
            return rows;
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar query", e);
        }
    }
}

package com.company.automation.report;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public final class ReportLogger {
    private static final ThreadLocal<ExtentTest> TEST = new ThreadLocal<>();
    private ReportLogger() {}

    public static void startTest(String name) { TEST.set(ExtentManager.getExtent().createTest(name)); }
    public static void pass(String msg) { TEST.get().pass(msg); }
    public static void fail(Throwable t) { TEST.get().fail(t); }
    public static void info(String title, String content) { TEST.get().log(Status.INFO, "<b>" + title + "</b><pre>" + content + "</pre>"); }
    public static void request(String request) { info("Request", request); }
    public static void response(String response) { info("Response", response); }
    public static void query(String query) { info("Database Query", query); }
    public static void kafka(String message) { info("Kafka Message", message); }
}

package com.company.automation.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class HealthCheckResponse {
    private String status;
}

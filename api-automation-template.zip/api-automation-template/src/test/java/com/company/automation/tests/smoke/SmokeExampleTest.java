package com.company.automation.tests.smoke;

import com.company.automation.base.BaseApiTest;
import com.company.automation.client.HealthCheckClient;
import com.company.automation.validation.CommonValidations;
import org.testng.annotations.Test;

public class SmokeExampleTest extends BaseApiTest {
    @Test(description = "[smoke] Healthcheck básico - deve validar disponibilidade mínima da API")
    public void dadoExecucaoSmoke_quandoConsultarHealthcheck_entaoDeveRetornar200() {
        CommonValidations.statusCode(new HealthCheckClient().getHealth(), 200);
    }
}

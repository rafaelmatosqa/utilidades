package com.company.automation.tests.healthcheck;

import com.company.automation.base.BaseApiTest;
import com.company.automation.client.HealthCheckClient;
import com.company.automation.validation.CommonValidations;
import io.restassured.response.ValidatableResponse;
import org.testng.annotations.Test;

public class HealthCheckTest extends BaseApiTest {
    private final HealthCheckClient client = new HealthCheckClient();

    @Test(description = "[healthcheck] GET /health - deve retornar status disponível")
    public void dadoApiDisponivel_quandoConsultarHealthcheck_entaoDeveRetornarStatusOk() {
        ValidatableResponse response = client.getHealth();
        CommonValidations.statusCode(response, 200);
        CommonValidations.schema(response, "schemas/healthcheck-schema.json");
        CommonValidations.fieldNotNull(response, "status");
    }
}

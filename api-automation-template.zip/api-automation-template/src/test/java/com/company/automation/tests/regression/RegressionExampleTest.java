package com.company.automation.tests.regression;

import com.company.automation.base.BaseApiTest;
import org.testng.SkipException;
import org.testng.annotations.Test;

public class RegressionExampleTest extends BaseApiTest {
    @Test(description = "[regression] Exemplo de regressão - substituir pelo contrato da API")
    public void dadoCenarioRegressivo_quandoExecutarContrato_entaoDeveValidarSchemaConteudoStatus() {
        throw new SkipException("Template: implementar casos de regressão por componente/endpoint.");
    }
}

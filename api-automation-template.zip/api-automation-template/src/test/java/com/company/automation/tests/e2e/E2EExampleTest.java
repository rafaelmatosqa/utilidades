package com.company.automation.tests.e2e;

import com.company.automation.base.BaseApiTest;
import org.testng.SkipException;
import org.testng.annotations.Test;

public class E2EExampleTest extends BaseApiTest {
    @Test(description = "[e2e] Exemplo de fluxo ponta a ponta - API + DB + Kafka")
    public void dadoFluxoE2E_quandoExecutarJornada_entaoDeveValidarApiBancoEKafka() {
        throw new SkipException("Template: implementar fluxo com múltiplas APIs, queries e mensagens Kafka.");
    }
}

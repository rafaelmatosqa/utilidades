package br.com.tm4j.junit5;

import br.com.tm4j.model.ExecutionStatus;
import br.com.tm4j.service.Tm4jService;
import java.time.Instant;
import java.util.Optional;
import org.junit.jupiter.api.extension.AfterTestExecutionCallback;
import org.junit.jupiter.api.extension.BeforeTestExecutionCallback;
import org.junit.jupiter.api.extension.ExtensionContext;

public class Tm4jExtension implements BeforeTestExecutionCallback, AfterTestExecutionCallback {
    private static final ExtensionContext.Namespace NAMESPACE = ExtensionContext.Namespace.create(Tm4jExtension.class);
    private final Tm4jService service = new Tm4jService();

    @Override
    public void beforeTestExecution(ExtensionContext context) {
        context.getStore(NAMESPACE).put("start", Instant.now().toEpochMilli());
        service.start(new JUnit5ExecutionAdapter(context, ExecutionStatus.IN_PROGRESS, null, 0));
    }

    @Override
    public void afterTestExecution(ExtensionContext context) {
        long start = context.getStore(NAMESPACE).get("start", Long.class) == null
                ? Instant.now().toEpochMilli()
                : context.getStore(NAMESPACE).get("start", Long.class);
        long duration = Math.max(0, Instant.now().toEpochMilli() - start);
        Optional<Throwable> throwable = context.getExecutionException();
        ExecutionStatus status = throwable.isPresent() ? ExecutionStatus.FAIL : ExecutionStatus.PASS;
        service.finish(new JUnit5ExecutionAdapter(context, status, throwable.orElse(null), duration));
    }
}

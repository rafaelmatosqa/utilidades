package br.com.tm4j.junit5;

import br.com.tm4j.annotation.TestCase;
import br.com.tm4j.model.ExecutionStatus;
import br.com.tm4j.spi.FrameworkExecution;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Optional;
import org.junit.jupiter.api.extension.ExtensionContext;

public class JUnit5ExecutionAdapter implements FrameworkExecution {
    private final ExtensionContext context;
    private final ExecutionStatus status;
    private final Throwable throwable;
    private final long duration;

    public JUnit5ExecutionAdapter(ExtensionContext context, ExecutionStatus status, Throwable throwable, long duration) {
        this.context = context;
        this.status = status;
        this.throwable = throwable;
        this.duration = duration;
    }

    @Override
    public Method method() {
        return context.getRequiredTestMethod();
    }

    @Override
    public String displayName() {
        return context.getDisplayName();
    }

    @Override
    public Throwable throwable() {
        return throwable;
    }

    @Override
    public ExecutionStatus status() {
        return status;
    }

    @Override
    public long duration() {
        return duration;
    }

    @Override
    public Optional<String> parameterValue(String name) {
        TestCase annotation = method().getAnnotation(TestCase.class);
        if (annotation == null) return Optional.empty();
        return Arrays.stream(annotation.key())
                .filter(k -> displayName() != null && displayName().contains(k))
                .findFirst();
    }
}

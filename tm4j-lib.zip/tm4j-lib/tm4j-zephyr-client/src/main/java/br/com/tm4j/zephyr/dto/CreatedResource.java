package br.com.tm4j.zephyr.dto;

public class CreatedResource {
    public Long id;
    public String key;
    public String self;
}

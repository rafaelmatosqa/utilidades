package br.com.tm4j.zephyr.client;

import br.com.tm4j.config.Tm4jConfig;
import br.com.tm4j.exception.*;
import br.com.tm4j.zephyr.dto.CreateExecutionRequest;
import br.com.tm4j.zephyr.dto.CreatedResource;
import br.com.tm4j.zephyr.dto.UpdateExecutionRequest;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import java.io.File;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ZephyrClientImpl implements ZephyrClient {
    private static final Logger log = LoggerFactory.getLogger(ZephyrClientImpl.class);
    private final Tm4jConfig config;

    public ZephyrClientImpl(Tm4jConfig config) {
        this.config = config;
    }

    @Override
    public String createExecution(CreateExecutionRequest request) {
        Response response = executeWithRetry(() -> RestAssured.given()
                .baseUri(config.getBaseUrl())
                .header("Authorization", "Bearer " + config.getToken())
                .contentType(ContentType.JSON)
                .body(request)
                .post("/testexecutions"));
        handleErrors(response, request);
        CreatedResource created = response.as(CreatedResource.class);
        String executionKey = created.key != null ? created.key : String.valueOf(created.id);
        log.info("[TM4J] Execution created: {}", executionKey);
        return executionKey;
    }

    @Override
    public void updateExecution(String executionKey, UpdateExecutionRequest request) {
        Response response = executeWithRetry(() -> RestAssured.given()
                .baseUri(config.getBaseUrl())
                .header("Authorization", "Bearer " + config.getToken())
                .contentType(ContentType.JSON)
                .body(request)
                .put("/testexecutions/{key}", executionKey));
        handleErrors(response, null);
        log.info("[TM4J] Execution updated: {} status={}", executionKey, request.statusName);
    }

    @Override
    public void uploadAttachment(String executionKey, File attachment) {
        if (attachment == null || !attachment.exists()) return;
        String fileName = URLEncoder.encode(attachment.getName(), StandardCharsets.UTF_8);
        Response response = executeWithRetry(() -> RestAssured.given()
                .baseUri(config.getBaseUrl())
                .header("Authorization", "Bearer " + config.getToken())
                .contentType("application/octet-stream")
                .body(attachment)
                .put("/testexecutions/{key}/attachments/{fileName}", executionKey, fileName));
        if (response.statusCode() >= 400) {
            throw new Tm4jCommunicationException("TM4J: Falha ao enviar anexo '" + attachment.getName() + "'. HTTP " + response.statusCode() + ": " + response.asString());
        }
        log.info("[TM4J] Attachment uploaded: {}", attachment.getName());
    }

    private Response executeWithRetry(RequestSupplier supplier) {
        int max = Math.max(1, config.getRetryMaxAttempts());
        RuntimeException last = null;
        for (int attempt = 1; attempt <= max; attempt++) {
            try {
                Response response = supplier.execute();
                int code = response.statusCode();
                if (!(code == 429 || code == 500 || code == 502 || code == 503 || code == 504) || attempt == max) {
                    return response;
                }
                sleep(attempt, response);
            } catch (RuntimeException e) {
                last = e;
                if (attempt == max) break;
                sleep(attempt, null);
            }
        }
        throw new Tm4jCommunicationException("TM4J: Falha de comunicação com Zephyr após " + max + " tentativas.", last);
    }

    private void sleep(int attempt, Response response) {
        try {
            String retryAfter = response == null ? null : response.header("Retry-After");
            long millis = retryAfter != null ? Long.parseLong(retryAfter) * 1000L : (long) Math.pow(2, attempt - 1) * 1000L;
            Thread.sleep(Math.min(millis, 8000L));
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (NumberFormatException ignored) {
        }
    }

    private void handleErrors(Response response, CreateExecutionRequest request) {
        int code = response.statusCode();
        if (code < 400) return;
        String body = response.asString();
        if (code == 401 || code == 403) throw new Tm4jAuthenticationException("TM4J: Falha de autenticação/autorização no Zephyr. HTTP " + code + ": " + body);
        if (request != null && (code == 400 || code == 404)) {
            String lower = body == null ? "" : body.toLowerCase();
            if (lower.contains("project") || lower.contains("projeto")) throw new Tm4jProjectNotFoundException("TM4J: Projeto '" + request.projectKey + "' inválido ou inexistente. " + body);
            if (lower.contains("cycle") || lower.contains("testcycle")) throw new Tm4jCycleNotFoundException("TM4J: Test Cycle '" + request.testCycleKey + "' inválido ou inexistente. " + body);
            if (lower.contains("test case") || lower.contains("testcase")) throw new Tm4jTestCaseNotFoundException("TM4J: Test Case '" + request.testCaseKey + "' inválido ou inexistente. " + body);
        }
        throw new Tm4jCommunicationException("TM4J: Erro HTTP " + code + " ao consumir Zephyr. Body: " + body);
    }

    @FunctionalInterface
    private interface RequestSupplier { Response execute(); }
}

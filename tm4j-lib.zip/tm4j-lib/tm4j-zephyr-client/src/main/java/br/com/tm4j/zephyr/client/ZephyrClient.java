package br.com.tm4j.zephyr.client;

import br.com.tm4j.zephyr.dto.CreateExecutionRequest;
import br.com.tm4j.zephyr.dto.UpdateExecutionRequest;
import java.io.File;

public interface ZephyrClient {
    String createExecution(CreateExecutionRequest request);
    void updateExecution(String executionKey, UpdateExecutionRequest request);
    void uploadAttachment(String executionKey, File attachment);
}

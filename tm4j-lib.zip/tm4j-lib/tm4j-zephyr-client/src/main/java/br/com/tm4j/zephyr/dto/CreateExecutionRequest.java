package br.com.tm4j.zephyr.dto;

import java.util.Map;

public class CreateExecutionRequest {
    public String projectKey;
    public String testCaseKey;
    public String testCycleKey;
    public String statusName;
    public String environmentName;
    public String actualEndDate;
    public Long executionTime;
    public String comment;
    public Map<String, Object> customFields;
}

package br.com.tm4j.zephyr.client;

import br.com.tm4j.config.Tm4jConfig;

public final class ZephyrClientFactory {
    private ZephyrClientFactory() {}
    public static ZephyrClient create(Tm4jConfig config) {
        return new ZephyrClientImpl(config);
    }
}

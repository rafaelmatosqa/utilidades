package br.com.tm4j.service;

import br.com.tm4j.annotation.TestCase;
import br.com.tm4j.config.Tm4jConfig;
import br.com.tm4j.config.Tm4jConfigLoader;
import br.com.tm4j.context.Tm4jContext;
import br.com.tm4j.exception.Tm4jException;
import br.com.tm4j.spi.FrameworkExecution;
import br.com.tm4j.util.TestCaseKeyResolver;
import br.com.tm4j.zephyr.client.ZephyrClient;
import br.com.tm4j.zephyr.client.ZephyrClientFactory;
import br.com.tm4j.zephyr.dto.CreateExecutionRequest;
import java.io.File;
import java.time.Instant;
import java.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Tm4jService {
    private static final Logger log = LoggerFactory.getLogger(Tm4jService.class);
    private final Tm4jConfig config;
    private final ZephyrClient client;

    public Tm4jService() {
        this.config = Tm4jConfigLoader.load();
        this.client = ZephyrClientFactory.create(config);
    }

    public void start(FrameworkExecution execution) {
        if (!config.getSendMode().isEnabled()) return;
        safe(() -> {
            if (execution.method().getAnnotation(TestCase.class) != null) {
                Tm4jContext.startTime(Instant.now());
            }
        });
    }

    public void finish(FrameworkExecution execution) {
        if (!config.getSendMode().isEnabled()) return;
        safe(() -> doFinish(execution));
    }

    private void doFinish(FrameworkExecution execution) {
        TestCase annotation = execution.method().getAnnotation(TestCase.class);
        if (annotation == null) return;

        String selectedKey = TestCaseKeyResolver.resolve(annotation, execution);
        CreateExecutionRequest request = new CreateExecutionRequest();
        request.projectKey = config.getProjectKey();
        request.testCaseKey = selectedKey;
        request.testCycleKey = emptyToNull(annotation.cycleKey());
        request.statusName = execution.status().zephyrName();
        request.environmentName = firstNonBlank(Tm4jContext.environment(), config.getEnvironment());
        request.executionTime = execution.duration() > 0 ? execution.duration() : calculateDuration();
        request.actualEndDate = DateTimeFormatter.ISO_INSTANT.format(Instant.now());
        request.comment = resolveComment(execution);
        request.customFields = Tm4jContext.customFields().isEmpty() ? null : Tm4jContext.customFields();

        String executionKey = client.createExecution(request);
        Tm4jContext.executionKey(executionKey);

        for (File attachment : Tm4jContext.attachments()) {
            try {
                client.uploadAttachment(executionKey, attachment);
            } catch (Tm4jException e) {
                if (config.isFailOnError()) throw e;
                log.warn("[TM4J] Attachment upload failed: {} - {}", attachment.getName(), e.getMessage());
            }
        }
        Tm4jContext.clear();
    }

    private Long calculateDuration() {
        Instant start = Tm4jContext.startTime();
        return start == null ? null : Math.max(0, Instant.now().toEpochMilli() - start.toEpochMilli());
    }

    private String resolveComment(FrameworkExecution execution) {
        String manual = Tm4jContext.comment();
        if (manual != null && !manual.isBlank()) return manual;
        Throwable throwable = execution.throwable();
        if (throwable != null && throwable.getMessage() != null) return throwable.getMessage();
        return execution.status().name().equals("PASS") ? "Execution completed successfully" : null;
    }

    private void safe(Runnable runnable) {
        try {
            runnable.run();
        } catch (Tm4jException e) {
            if (config.isFailOnError()) throw e;
            log.error("[TM4J] {}", e.getMessage());
        } catch (RuntimeException e) {
            if (config.isFailOnError()) throw e;
            log.error("[TM4J] Erro inesperado na integração: {}", e.getMessage(), e);
        }
    }

    private static String emptyToNull(String value) { return value == null || value.isBlank() ? null : value.trim(); }
    private static String firstNonBlank(String first, String second) { return first != null && !first.isBlank() ? first : second; }
}

package br.com.tm4j.zephyr.dto;

public class UpdateExecutionRequest {
    public String statusName;
    public String environmentName;
    public String actualEndDate;
    public Long executionTime;
    public String comment;
}

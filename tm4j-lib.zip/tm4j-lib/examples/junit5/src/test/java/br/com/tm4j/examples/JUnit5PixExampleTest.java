package br.com.tm4j.examples;

import br.com.tm4j.annotation.TestCase;
import br.com.tm4j.context.Tm4jContext;
import br.com.tm4j.junit5.Tm4jExtension;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

@ExtendWith(Tm4jExtension.class)
class JUnit5PixExampleTest {

    @ParameterizedTest(name = "{0} {1}")
    @CsvSource({
            "cpf,PIX-T123",
            "email,PIX-T124"
    })
    @TestCase(key = {"PIX-T123", "PIX-T124"}, cycleKey = "PIX-R50")
    void deveConsultarPix(String tipo, String testCaseKey) {
        Tm4jContext.testCaseKey(testCaseKey);
        Tm4jContext.customField("Tipo", tipo);
        Tm4jContext.environment("QA");
    }
}

package br.com.tm4j.examples;

import br.com.tm4j.annotation.TestCase;
import br.com.tm4j.context.Tm4jContext;
import br.com.tm4j.testng.Tm4jTestNgListener;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(Tm4jTestNgListener.class)
public class TestNgPixExampleTest {

    @DataProvider(name = "chaves")
    public Object[][] chaves() {
        return new Object[][] {
                {"cpf", "PIX-T123"},
                {"email", "PIX-T124"}
        };
    }

    @Test(dataProvider = "chaves")
    @TestCase(key = {"PIX-T123", "PIX-T124"}, cycleKey = "PIX-R50")
    public void deveConsultarPix(String tipo, String testCaseKey) {
        Tm4jContext.testCaseKey(testCaseKey);
        Tm4jContext.customField("Tipo", tipo);
        Tm4jContext.environment("QA");
    }
}

package br.com.tm4j.testng;

import br.com.tm4j.service.Tm4jService;
import org.testng.IInvokedMethod;
import org.testng.IInvokedMethodListener;
import org.testng.ITestResult;

public class Tm4jTestNgListener implements IInvokedMethodListener {
    private final Tm4jService service = new Tm4jService();

    @Override
    public void beforeInvocation(IInvokedMethod method, ITestResult testResult) {
        if (!method.isTestMethod()) return;
        service.start(new TestNgExecutionAdapter(testResult));
    }

    @Override
    public void afterInvocation(IInvokedMethod method, ITestResult testResult) {
        if (!method.isTestMethod()) return;
        if (isFailureThatWillBeRetried(testResult)) {
            return;
        }
        service.finish(new TestNgExecutionAdapter(testResult));
    }

    private boolean isFailureThatWillBeRetried(ITestResult result) {
        if (result.getStatus() != ITestResult.FAILURE) return false;
        try {
            Object value = result.getClass().getMethod("wasRetried").invoke(result);
            return Boolean.TRUE.equals(value);
        } catch (ReflectiveOperationException ignored) {
            return false;
        }
    }
}

package br.com.tm4j.testng;

import br.com.tm4j.model.ExecutionStatus;
import br.com.tm4j.spi.FrameworkExecution;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.Optional;
import org.testng.ITestResult;

public class TestNgExecutionAdapter implements FrameworkExecution {
    private final ITestResult result;
    private final ExecutionStatus forcedStatus;

    public TestNgExecutionAdapter(ITestResult result) {
        this(result, null);
    }

    public TestNgExecutionAdapter(ITestResult result, ExecutionStatus forcedStatus) {
        this.result = result;
        this.forcedStatus = forcedStatus;
    }

    @Override
    public Method method() {
        return result.getMethod().getConstructorOrMethod().getMethod();
    }

    @Override
    public String displayName() {
        return result.getName();
    }

    @Override
    public Throwable throwable() {
        return result.getThrowable();
    }

    @Override
    public ExecutionStatus status() {
        if (forcedStatus != null) return forcedStatus;
        return switch (result.getStatus()) {
            case ITestResult.SUCCESS -> ExecutionStatus.PASS;
            case ITestResult.SKIP -> ExecutionStatus.SKIP;
            default -> ExecutionStatus.FAIL;
        };
    }

    @Override
    public long duration() {
        return Math.max(0, result.getEndMillis() - result.getStartMillis());
    }

    @Override
    public Optional<String> parameterValue(String name) {
        Parameter[] parameters = method().getParameters();
        Object[] values = result.getParameters();
        for (int i = 0; i < parameters.length && i < values.length; i++) {
            if (parameters[i].getName().equalsIgnoreCase(name) && values[i] != null) {
                return Optional.of(values[i].toString());
            }
        }
        return Optional.empty();
    }
}

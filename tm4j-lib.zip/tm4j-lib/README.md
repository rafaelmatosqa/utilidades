# TM4J Lib

Biblioteca Java para registrar execuções automatizadas no Zephyr Scale Cloud/TM4J.

## Módulos

- `tm4j-core`: annotation, contexto, configuração, exceções e SPI.
- `tm4j-zephyr-client`: cliente REST do Zephyr Scale Cloud e serviço de integração.
- `tm4j-testng`: listener para TestNG.
- `tm4j-junit5`: extension para JUnit 5.

## Configuração obrigatória

Todo projeto consumidor deve ter:

```text
src/test/resources/tm4j.properties
```

### Local

```properties
jira.send=ON
jira.token=token-local
jira.projectKey=PIX
jira.environment=QA
jira.failOnError=false
```

### CI

```properties
jira.send=CI
jira.projectKey=PIX
jira.environment=QA
jira.failOnError=false
```

No modo `CI`, o token é lido pelo `VaultTokenProvider`. A implementação padrão lê `JIRA_TOKEN` do ambiente. Substitua esse provider pela integração real com Vault do seu ambiente.

### Desligado

```properties
jira.send=OFF
```

## Uso com TestNG

```java
@Listeners(Tm4jTestNgListener.class)
public class PixTest {

    @Test
    @TestCase(key = {"PIX-T123"}, cycleKey = "PIX-R50")
    public void deveConsultarPix() {
        Tm4jContext.customField("Build", "1.0.0");
        Tm4jContext.environment("QA");
    }
}
```

## Uso com DataProvider

```java
@Test(dataProvider = "dados")
@TestCase(key = {"PIX-T123", "PIX-T124"}, cycleKey = "PIX-R50")
public void deveConsultarPix(String tipo, String testCaseKey) {
    Tm4jContext.testCaseKey(testCaseKey);
    Tm4jContext.customField("Tipo", tipo);
}
```

## Uso com JUnit 5

```java
@ExtendWith(Tm4jExtension.class)
class PixTest {

    @ParameterizedTest(name = "{0} {1}")
    @CsvSource({"cpf,PIX-T123", "email,PIX-T124"})
    @TestCase(key = {"PIX-T123", "PIX-T124"}, cycleKey = "PIX-R50")
    void deveConsultarPix(String tipo, String testCaseKey) {
        Tm4jContext.testCaseKey(testCaseKey);
        Tm4jContext.customField("Tipo", tipo);
    }
}
```

## Erros tratados

- `Tm4jProjectNotFoundException`
- `Tm4jCycleNotFoundException`
- `Tm4jTestCaseNotFoundException`
- `Tm4jAuthenticationException`
- `Tm4jVaultException`
- `Tm4jCommunicationException`
- `Tm4jConfigurationException`
- `Tm4jMultipleTestCasesException`

`jira.failOnError=false` apenas loga erro e não quebra a suíte. `jira.failOnError=true` propaga a exceção.

## Publicação no GitLab Package Registry

A pipeline `.gitlab-ci.yml` executa:

```bash
gradle clean build
gradle publish
```

Para release, crie uma tag Git. Para snapshot, faça merge na branch `main`.

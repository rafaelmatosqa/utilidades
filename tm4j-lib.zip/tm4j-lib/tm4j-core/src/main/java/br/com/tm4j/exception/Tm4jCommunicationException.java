package br.com.tm4j.exception;
public class Tm4jCommunicationException extends Tm4jException {
    public Tm4jCommunicationException(String message) { super(message); }
    public Tm4jCommunicationException(String message, Throwable cause) { super(message, cause); }
}

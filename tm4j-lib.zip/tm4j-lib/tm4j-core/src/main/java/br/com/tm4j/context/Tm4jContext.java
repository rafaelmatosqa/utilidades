package br.com.tm4j.context;

import java.io.File;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class Tm4jContext {
    private static final ThreadLocal<String> EXECUTION_KEY = new ThreadLocal<>();
    private static final ThreadLocal<String> SELECTED_TEST_CASE_KEY = new ThreadLocal<>();
    private static final ThreadLocal<String> ENVIRONMENT = new ThreadLocal<>();
    private static final ThreadLocal<String> COMMENT = new ThreadLocal<>();
    private static final ThreadLocal<Instant> START_TIME = new ThreadLocal<>();
    private static final ThreadLocal<Map<String, Object>> CUSTOM_FIELDS = ThreadLocal.withInitial(HashMap::new);
    private static final ThreadLocal<List<File>> ATTACHMENTS = ThreadLocal.withInitial(ArrayList::new);

    private Tm4jContext() {}

    public static void testCaseKey(String key) { SELECTED_TEST_CASE_KEY.set(key); }
    public static String testCaseKey() { return SELECTED_TEST_CASE_KEY.get(); }
    public static void customField(String field, Object value) { CUSTOM_FIELDS.get().put(field, value); }
    public static Map<String, Object> customFields() { return new HashMap<>(CUSTOM_FIELDS.get()); }
    public static void environment(String environment) { ENVIRONMENT.set(environment); }
    public static String environment() { return ENVIRONMENT.get(); }
    public static void comment(String comment) { COMMENT.set(comment); }
    public static String comment() { return COMMENT.get(); }
    public static void attachment(File attachment) { if (attachment != null) ATTACHMENTS.get().add(attachment); }
    public static List<File> attachments() { return new ArrayList<>(ATTACHMENTS.get()); }
    public static void executionKey(String key) { EXECUTION_KEY.set(key); }
    public static String executionKey() { return EXECUTION_KEY.get(); }
    public static void startTime(Instant instant) { START_TIME.set(instant); }
    public static Instant startTime() { return START_TIME.get(); }

    public static void clear() {
        EXECUTION_KEY.remove();
        SELECTED_TEST_CASE_KEY.remove();
        ENVIRONMENT.remove();
        COMMENT.remove();
        START_TIME.remove();
        CUSTOM_FIELDS.remove();
        ATTACHMENTS.remove();
    }
}

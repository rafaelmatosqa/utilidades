package br.com.tm4j.config;

public final class Tm4jConfig {
    private final SendMode sendMode;
    private final String token;
    private final String projectKey;
    private final String environment;
    private final boolean failOnError;
    private final String baseUrl;
    private final int retryMaxAttempts;

    public Tm4jConfig(SendMode sendMode, String token, String projectKey, String environment,
                      boolean failOnError, String baseUrl, int retryMaxAttempts) {
        this.sendMode = sendMode;
        this.token = token;
        this.projectKey = projectKey;
        this.environment = environment;
        this.failOnError = failOnError;
        this.baseUrl = baseUrl;
        this.retryMaxAttempts = retryMaxAttempts;
    }

    public SendMode getSendMode() { return sendMode; }
    public String getToken() { return token; }
    public String getProjectKey() { return projectKey; }
    public String getEnvironment() { return environment; }
    public boolean isFailOnError() { return failOnError; }
    public String getBaseUrl() { return baseUrl; }
    public int getRetryMaxAttempts() { return retryMaxAttempts; }
}

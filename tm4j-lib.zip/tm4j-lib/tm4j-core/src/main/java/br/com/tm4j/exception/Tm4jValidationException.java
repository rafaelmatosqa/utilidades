package br.com.tm4j.exception;
public class Tm4jValidationException extends Tm4jException {
    public Tm4jValidationException(String message) { super(message); }
    public Tm4jValidationException(String message, Throwable cause) { super(message, cause); }
}

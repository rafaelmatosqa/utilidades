package br.com.tm4j.spi;

import br.com.tm4j.model.ExecutionStatus;
import java.lang.reflect.Method;
import java.util.Optional;

public interface FrameworkExecution {
    Method method();
    String displayName();
    Throwable throwable();
    ExecutionStatus status();
    long duration();
    default Optional<String> parameterValue(String name) { return Optional.empty(); }
}

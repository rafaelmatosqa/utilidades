package br.com.tm4j.model;

public enum ExecutionStatus {
    PASS("Pass"), FAIL("Fail"), SKIP("Blocked"), IN_PROGRESS("In Progress");
    private final String zephyrName;
    ExecutionStatus(String zephyrName) { this.zephyrName = zephyrName; }
    public String zephyrName() { return zephyrName; }
}

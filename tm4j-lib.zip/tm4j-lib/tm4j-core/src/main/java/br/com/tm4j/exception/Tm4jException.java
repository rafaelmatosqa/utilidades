package br.com.tm4j.exception;
public class Tm4jException extends RuntimeException {
    public Tm4jException(String message) { super(message); }
    public Tm4jException(String message, Throwable cause) { super(message, cause); }
}

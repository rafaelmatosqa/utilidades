package br.com.tm4j.exception;
public class Tm4jProjectNotFoundException extends Tm4jValidationException {
    public Tm4jProjectNotFoundException(String message) { super(message); }
    public Tm4jProjectNotFoundException(String message, Throwable cause) { super(message, cause); }
}

package br.com.tm4j.config;

public enum SendMode {
    ON, CI, OFF;

    public boolean isEnabled() {
        return this == ON || this == CI;
    }

    public static SendMode from(String value) {
        if (value == null || value.isBlank()) return OFF;
        try {
            return valueOf(value.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new br.com.tm4j.exception.Tm4jConfigurationException(
                    "TM4J: jira.send inválido. Valores aceitos: ON, CI, OFF. Valor recebido: " + value, e);
        }
    }
}

package br.com.tm4j.exception;
public class Tm4jCycleNotFoundException extends Tm4jValidationException {
    public Tm4jCycleNotFoundException(String message) { super(message); }
    public Tm4jCycleNotFoundException(String message, Throwable cause) { super(message, cause); }
}

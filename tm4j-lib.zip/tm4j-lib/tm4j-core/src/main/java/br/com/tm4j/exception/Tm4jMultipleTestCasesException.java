package br.com.tm4j.exception;
public class Tm4jMultipleTestCasesException extends Tm4jValidationException {
    public Tm4jMultipleTestCasesException(String message) { super(message); }
    public Tm4jMultipleTestCasesException(String message, Throwable cause) { super(message, cause); }
}

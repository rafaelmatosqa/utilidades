package br.com.tm4j.config;

import br.com.tm4j.exception.Tm4jConfigurationException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public final class Tm4jConfigLoader {
    private static volatile Tm4jConfig cached;

    private Tm4jConfigLoader() {}

    public static Tm4jConfig load() {
        if (cached == null) {
            synchronized (Tm4jConfigLoader.class) {
                if (cached == null) cached = doLoad();
            }
        }
        return cached;
    }

    static Tm4jConfig doLoad() {
        Properties props = new Properties();
        try (InputStream input = Thread.currentThread().getContextClassLoader().getResourceAsStream("tm4j.properties")) {
            if (input == null) return new Tm4jConfig(SendMode.OFF, null, null, null, false,
                    "https://api.zephyrscale.smartbear.com/v2", 3);
            props.load(input);
        } catch (IOException e) {
            throw new Tm4jConfigurationException("TM4J: Erro ao carregar tm4j.properties.", e);
        }

        SendMode mode = SendMode.from(props.getProperty("jira.send", "OFF"));
        String projectKey = blankToNull(props.getProperty("jira.projectKey"));
        String environment = blankToNull(props.getProperty("jira.environment"));
        boolean failOnError = Boolean.parseBoolean(props.getProperty("jira.failOnError", "false"));
        String baseUrl = props.getProperty("jira.baseUrl", "https://api.zephyrscale.smartbear.com/v2").trim();
        int retry = Integer.parseInt(props.getProperty("jira.retry.maxAttempts", "3"));

        String token = null;
        if (mode == SendMode.ON) token = blankToNull(props.getProperty("jira.token"));
        if (mode == SendMode.CI) token = VaultTokenProvider.getToken();

        validate(mode, token, projectKey);
        return new Tm4jConfig(mode, token, projectKey, environment, failOnError, baseUrl, retry);
    }

    private static void validate(SendMode mode, String token, String projectKey) {
        if (mode == SendMode.OFF) return;
        if (projectKey == null) throw new Tm4jConfigurationException("TM4J: jira.projectKey é obrigatório quando jira.send=" + mode + ".");
        if (mode == SendMode.ON && token == null) throw new Tm4jConfigurationException("TM4J: jira.token é obrigatório quando jira.send=ON.");
        if (mode == SendMode.CI && token == null) throw new Tm4jConfigurationException("TM4J: Vault retornou token inválido ou vazio.");
    }

    private static String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }
}

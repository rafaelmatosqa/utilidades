package br.com.tm4j.exception;
public class Tm4jVaultException extends Tm4jException {
    public Tm4jVaultException(String message) { super(message); }
    public Tm4jVaultException(String message, Throwable cause) { super(message, cause); }
}

package br.com.tm4j.util;

import br.com.tm4j.annotation.TestCase;
import br.com.tm4j.context.Tm4jContext;
import br.com.tm4j.exception.Tm4jMultipleTestCasesException;
import br.com.tm4j.spi.FrameworkExecution;
import java.util.Arrays;

public final class TestCaseKeyResolver {
    private TestCaseKeyResolver() {}

    public static String resolve(TestCase annotation, FrameworkExecution execution) {
        String contextKey = blankToNull(Tm4jContext.testCaseKey());
        if (contextKey != null) return validateDeclared(annotation, contextKey);

        String testCaseKey = execution.parameterValue("testCaseKey").orElse(null);
        if (blankToNull(testCaseKey) != null) return validateDeclared(annotation, testCaseKey);

        String jiraKey = execution.parameterValue("jiraKey").orElse(null);
        if (blankToNull(jiraKey) != null) return validateDeclared(annotation, jiraKey);

        if (annotation.key().length == 1) return annotation.key()[0];

        throw new Tm4jMultipleTestCasesException("TM4J: Foram encontradas múltiplas testCaseKeys na annotation "
                + Arrays.toString(annotation.key()) + ", porém nenhuma foi selecionada. Use Tm4jContext.testCaseKey(...), parâmetro testCaseKey ou parâmetro jiraKey.");
    }

    private static String validateDeclared(TestCase annotation, String key) {
        boolean declared = Arrays.stream(annotation.key()).anyMatch(k -> k.equalsIgnoreCase(key));
        if (!declared) {
            throw new Tm4jMultipleTestCasesException("TM4J: testCaseKey selecionada '" + key + "' não existe na annotation: " + Arrays.toString(annotation.key()));
        }
        return key;
    }

    private static String blankToNull(String value) { return value == null || value.isBlank() ? null : value.trim(); }
}

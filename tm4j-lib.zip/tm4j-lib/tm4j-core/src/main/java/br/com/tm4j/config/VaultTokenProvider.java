package br.com.tm4j.config;

import br.com.tm4j.exception.Tm4jVaultException;

public final class VaultTokenProvider {
    private VaultTokenProvider() {}

    public static String getToken() {
        String token = System.getenv("JIRA_TOKEN");
        if (token == null || token.isBlank()) {
            throw new Tm4jVaultException("TM4J: Não foi possível recuperar o token do Vault. Variável JIRA_TOKEN ausente ou vazia.");
        }
        return token.trim();
    }
}

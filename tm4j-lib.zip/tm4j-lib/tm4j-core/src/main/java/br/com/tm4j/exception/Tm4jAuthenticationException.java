package br.com.tm4j.exception;
public class Tm4jAuthenticationException extends Tm4jException {
    public Tm4jAuthenticationException(String message) { super(message); }
    public Tm4jAuthenticationException(String message, Throwable cause) { super(message, cause); }
}

package br.com.tm4j.exception;
public class Tm4jConfigurationException extends Tm4jException {
    public Tm4jConfigurationException(String message) { super(message); }
    public Tm4jConfigurationException(String message, Throwable cause) { super(message, cause); }
}
